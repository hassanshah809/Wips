package controller.form;

import java.util.ArrayList;
import java.util.List;

import model.Wips;
import model.user.EndUser;
import model.wips.forms.CoupleForSending;
import model.wips.forms.Form;
import model.wips.intermediates.AbsReq;
import model.wips.intermediates.AndReq;
import model.wips.intermediates.OrReq;

public class RecipientWindow {

	private CoupleForSending[] coupleForSending;
	private AbsReq selectedStates = null;

	public void show() {
		Wips wips = Wips.getInstance();
		int indexOfNextStates = wips.getIndexOfNextState();
		selectedStates = wips.getCurrentWorkFlow().getCurrentState().getStartWithMe().get(indexOfNextStates);
		coupleForSending = new CoupleForSending[selectedStates.size()];

		if (selectedStates.size() > 1) {
			AndReq andSelected = (AndReq) selectedStates;
			for (int i = 0; i < coupleForSending.length; i++) {
				coupleForSending[i] = new CoupleForSending(
						andSelected.getAndTransitions().get(i).getEndState().getDistinctValues());
			}
		} else {
			OrReq orselectedStates = (OrReq) selectedStates;
			coupleForSending[0] = new CoupleForSending(
					orselectedStates.getTransition().getEndState().getDistinctValues());
		}
	}

	public List<EndUser> compileListOfUsers() {
		List<EndUser> endUsers = new ArrayList<>();
		if (selectedStates != null) {
			for (int i = 0; i < coupleForSending.length; i++) {
				endUsers.add(coupleForSending[i].getEndUser());
			}
		}
		return endUsers;
	}

	public void send() {
		if (Wips.getInstance().getCurrentWorkFlow().getCurrentState().isAllowedtoSend()) {
			EndUser endUser = (EndUser) Wips.getInstance().getCurrentuser();
			Form form = new Form("dummy");
			for (EndUser user : compileListOfUsers()) {
				endUser.send(form, user);
				form.addUser(user);
			}
			form.updateUsers();
			selectedStates.markedSend();
		}
	}

	/**
	 * This method will return the user to the window for the FormController
	 * without making any changes to the system.
	 */
	public void cancel() {
		// Parent p = FXMLLoader.load(getClass().getResource("Path to the view
		// FXML file"));
		// View Package will have a class called openSCreen and it will have a
		// method called "openScreen"
		// It will take 3 parameters openScreen(String fxmlfile, ActionEvent e,
		// String title, Parent p);
	}
}
