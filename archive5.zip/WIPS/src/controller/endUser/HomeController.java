package controller.endUser;

public class HomeController {

	
	/**
	 * This method will open �All workflow� tab.
	 */
	public void allWorkFlowController(){
		
	}
	
	/**
	 * This method will open �Active Workflow� tab.
	 */
	public void activeWorkFlows() {
		
	}
	
	/**
	 * This method will open �Notifications� tab.
	 */
	public void notifController() {
		
	}
}
