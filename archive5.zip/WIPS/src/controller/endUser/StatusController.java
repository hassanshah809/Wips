package controller.endUser;

import model.wips.WorkFlow;

public class StatusController {

	/**
	 * This methods takes in workflow as a parameter, it will show the 
	 * status of the workflow that was passed in the method. It will show the status in the form of string.
	 * @param workflow WorkFlow
	 */
	public void showStatus(WorkFlow workflow) {
		//read the log file associated with the workflow
	}
}
