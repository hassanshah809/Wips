package model.wips.forms.fields;

import javafx.scene.control.Button;

public class FButton extends Button implements Field {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor to make different types of buttons
	 */
	public FButton() {
		super();
	}
}
