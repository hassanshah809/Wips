package model.wips.forms.fields;

import java.io.Serializable;

/**
 * This is an empty interface that defines the Field type
 *
 */
public interface Field extends Serializable{
	
	
}
