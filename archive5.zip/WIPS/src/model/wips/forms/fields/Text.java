package model.wips.forms.fields;

import javafx.scene.control.TextField;

public class Text extends TextField implements Field {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Constructor to make different types of text objects
	 */
	public Text() {
		super();
		// TODO Auto-generated constructor stub
	}
}
