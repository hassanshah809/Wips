package model.parser.intermediates;

public class GenInter<T> extends Intermediate<T>{
	
}
