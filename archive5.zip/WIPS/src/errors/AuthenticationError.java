package errors;

import java.util.List;

public class AuthenticationError extends AbsError{

	public AuthenticationError() {
		super();
	}
}
