package errors;

import java.util.List;

public class ParserError extends AbsError {

	public ParserError() {
		super();
	}
}
